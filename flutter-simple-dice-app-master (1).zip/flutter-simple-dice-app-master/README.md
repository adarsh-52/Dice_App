

# Simpl Dice App 🎲

The app has been developed as part of the Flutter course mentioned below.

>This is a companion project to The App Brewery's Complete Flutter Development Bootcamp, check out the full course at [www.appbrewery.co](https://www.appbrewery.co/)

# Run App  🎲
1. Clone the repository
2. Run  `flutter packages get` to download the required packages
3. Run the app with `flutter run` or play button on your emulator/physical device.